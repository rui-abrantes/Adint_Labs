from flask import Flask, render_template, request, send_from_directory
import os
app = Flask(__name__)
     
@app.route("/")
def index():
    return render_template("index.html", message="Dynamic content!")   

@app.route("/listFiles")
def listFiles():
    # TODO 1
    #get dir listing
    return render_template("listFiles.html") 

@app.route('/getFile/<path:filename>', methods=['GET', 'POST'])
def getFile(filename):
    #TODO 3
    # file verification

    #TODO 5
    # send file
    return ""

# TODO 4
# redirected page


# TODO 6
#/files




@app.route("/newFile")
def newFileForm():
    return render_template("newFile.html") 

#TODO 7
#createFile

#TODO 8
#upload files

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8000, debug=True)